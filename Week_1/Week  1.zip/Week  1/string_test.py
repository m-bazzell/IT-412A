string_var = 'Hello\n\t'

string_name = "Mindy Bazzell"

string_name.upper()
print(string_var + " " + string_name.upper())

print(string_name)


print(string_var + "\n\t" + string_name)