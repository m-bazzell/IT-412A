favorite_marvel_movies = ["Avengers", "Thor:Ragnorok", "Captain America:Winter Soldier","Black Panther", "Guardians of the Galaxy"]

print(favorite_marvel_movies)

favorite_marvel_movies.sort()
print(favorite_marvel_movies)

favorite_marvel_movies.reverse()
print(favorite_marvel_movies) 
