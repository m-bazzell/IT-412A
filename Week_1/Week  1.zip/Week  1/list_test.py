list_of_chores = ["Take out Trash", "Wash Dishes", "Cut Grass" , "Dust Coffee Table"]

for chore in list_of_chores[1:3]: 
    chore = chore + " (10 minutes!)"
    print(chore + " - Done!")