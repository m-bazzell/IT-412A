#chapter 2 Try it Yourself Exercises
#page 19

#2-1 printing variable with message 
message = "Hello welcome to IT 412"
print(message)

#2-2 changing the variable and printing
message = "I love programming with Python"
print(message)

#page 25

#2-3 creating and printing a personal message 
personal_message = "Hello Tom, thank you for going above and beyond for me in this class!"
print(personal_message)

#2-4
name = "George"
print(name.upper())
print(name.lower())
print(name.title())

#2-5
quote = "Buddha once said:\"Be where you are; otherwise you will miss your life.\""
print(quote)

#2-6 
name_quote = "Buddha said "
message_quote = "\"Be where you are; otherwise you will miss your life\""
new_quote = name_quote + message_quote
print(new_quote)

#2-7 
name_var = ' Mindy \n  '
name_var2 = '\t Bob \n'
print(name_var)
print(name_var2)
print(name_var.lstrip())
print(name_var.rstrip())
print(name_var.strip())

#2-8 
print(6+2)
print(4*2)
print(10-2)
print(40/5)

#2-9
favorite_num = 30
print("This is my favorite number: " + str(favorite_num))