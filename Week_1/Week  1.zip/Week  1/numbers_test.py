addition_result = 3 + 4

print(addition_result)

math_result = 3 + .5

print(math_result)

numberThree = 3 
numberFour = 4 

math_result = numberThree * numberFour + numberThree

print(math_result)