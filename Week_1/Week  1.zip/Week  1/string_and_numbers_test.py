string_variable  = "Today is the "

number_variable = 22

month_variable  = " day of the month"

output_variable = string_variable + str(number_variable) + month_variable

print(output_variable)